export default function Product(meals){
    return(
    <div className="column is-4">
    <div className="card large">
        <div className="card-image">
            <figure className="image">
                <img src={meals.strMealThumb}
                    alt={meals.strMeal} />
            </figure>
        </div>
        <div className="card-content">
            <div className="media">
                <div className="media-content">
                    <p className="title is-4">{meals.strMeal}</p>
                </div>
            </div>

            <div className="content">
                <p>See more about {meals.strMeal}
                <a href={`?code=${meals.idMeal}`}> here</a>.
                </p>
                <button onClick={(evt)=>{
                    const favourites = JSON.parse(localStorage.getItem("favourites")) || [];
                    if(meals.buttonText == "add"){
                        for(let i = 0; i < favourites.length; i += 1){
                            if(favourites[i].code == meals.idMeal ){
                                alert(`product ${meals.strMeal} is already a favourite`);
                                return;
                            }
                        }
                        favourites.push(meals);
                    }else{
                        const idMeal = meals.idMeal;
                        for(let i = 0; i < favourites.length; i += 1){
                            if(favourites[i].idMeal == idMeal){
                                favourites.splice(i, 1);
                                break;
                            }
                        }
                    }
                    localStorage.setItem("favourites", JSON.stringify(favourites));
                    meals.updateFavourites(favourites);
                }}>{meals.buttonText}</button>
            </div>
        </div>
    </div>
</div>
    );
}